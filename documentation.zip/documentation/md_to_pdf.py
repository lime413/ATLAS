from pathlib import Path
import markdown2
from xhtml2pdf import pisa

SRC = Path(__file__).with_name("report_stage_2.md")
DST = SRC.with_suffix(".pdf")

html_body = markdown2.markdown(
    SRC.read_text(encoding="utf-8"),
    extras=["tables", "fenced-code-blocks", "header-ids"],
)

full_html = f"""<!DOCTYPE html>
<html><head><meta charset="utf-8">
<style>
  body {{ font-family: Helvetica, Arial, sans-serif; margin: 40px 50px; font-size: 11px; line-height: 1.5; color: #222; }}
  h2 {{ margin-top: 1.5em; font-size: 16px; }}
  h3 {{ margin-top: 1.2em; font-size: 13px; }}
  table {{ border-collapse: collapse; width: 100%; margin: 1em 0; font-size: 10px; }}
  th, td {{ border: 1px solid #bbb; padding: 5px 8px; text-align: left; }}
  th {{ background-color: #f0f0f0; }}
  code {{ background-color: #f4f4f4; padding: 1px 3px; font-size: 10px; }}
  pre {{ background-color: #f4f4f4; padding: 8px; }}
  strong {{ font-weight: bold; }}
</style>
</head><body>{html_body}</body></html>"""

with open(DST, "wb") as f:
    status = pisa.CreatePDF(full_html, dest=f, encoding="utf-8")

if status.err:
    print(f"Error converting to PDF: {status.err}")
else:
    print(f"Saved: {DST}")
