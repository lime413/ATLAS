# ATLAS - Agent Reference

Quick-reference for an AI coding agent working on this repo. Describes the current state of the codebase, data layout, environment variables, and known issues.

## Project goal

Build and evaluate a hybrid RAG pipeline (dense + sparse retrieval) over Wikipedia, using a local GGUF LLM served by `llama-server`.

## Directory layout

```text
ATLAS/
|-- rag/
|   |-- index.py            # Build hybrid index (chunks -> FAISS + SQLite FTS5)
|   |-- search.py           # Retrieve passages (dense + sparse RRF) + optional RAG answer
|   |-- embedder_factory.py # Jina v3 embedder loader (GPU default, optional dtype knobs)
|   `-- constants.py        # Shared constants, including default LLM model
|-- eval/
|   |-- run_rag_hard_eval.py      # Full eval: generate answers + EM/F1/BERTScore
|   |-- build_train_hard_subset.py# Sample N pages from train_hard, write smaller DB + JSONL
|   `-- metrics.py                # EM, token-F1, BERTScore helpers
|-- data/                   # (git-ignored) SQLite DBs, JSONL files, index dirs
|-- models/                 # (git-ignored) GGUF model files
|-- output/                 # (git-ignored) evaluation outputs
|-- pyproject.toml          # Python >=3.10, deps managed by uv
`-- README.md
```

## Key data files (under `data/`, git-ignored)

| File | Description |
|------|-------------|
| `wikipedia_pages.sqlite` | Full ~5.9M-page Wikipedia dump |
| `wikipedia_pages_50k.sqlite` | 50k-page subset (39k linked + 10k random) |
| `wikipedia_pages_hard_10k.sqlite` | 10k random pages linked from train_hard |
| `train.jsonl` | Full training questions |
| `train_hard.jsonl` | Hard questions (LLM could not answer without context) |
| `train_hard_subset_10k.jsonl` | Questions whose gold pages are inside the 10k subset |
| `index_50k_rawish/` | Pre-built index with `faiss.index` + `passages.sqlite` |
| `index_hard_10k/` | Typical target index dir for the 10k subset |

## Dense index

- Dense retrieval uses FAISS only.
- Dense vectors are stored in `index_dir/faiss.index`.
- Sparse retrieval uses SQLite FTS5 in `index_dir/passages.sqlite`.
- Retrieval loads the FAISS index into the Python process, so RAM usage depends on corpus size and embedding dimension.

## Environment variables

| Variable | Default | Purpose |
|----------|---------|---------|
| `ATLAS_EMBED_TORCH_DTYPE` | `""` (float32) | `float16` / `bfloat16` to halve embedder VRAM |
| `ATLAS_EMBED_DEVICE` | `cuda` (if available) | Force device for the Jina v3 embedder |
| `ATLAS_TORCH_INTRAOP_THREADS` | - | Limit PyTorch intra-op threads |
| `ATLAS_TORCH_INTEROP_THREADS` | - | Limit PyTorch inter-op threads |
| `ATLAS_SQLITE_CACHE_KB` | `4096` | SQLite page cache (KiB) |
| `ATLAS_SQLITE_MMAP_MB` | `128` | SQLite mmap cap (MB, 0 = off) |
| `ATLAS_PASSAGE_FETCH_CHUNK` | `400` | Max ids per `WHERE IN` batch |

## LLM server

```powershell
llama-server.exe -m models\gemma3\gemma-3-4b-it-Q4_K_M.gguf -ngl 99 -c 8192 --host 127.0.0.1 --port 8080
```

OpenAI-compatible on `http://127.0.0.1:8080/v1`. Model id for `--model` is always `gemma-3-4b-it-Q4_K_M.gguf`.

## Typical commands

```bash
# Subset
uv run python eval/build_train_hard_subset.py --num-pages 10000 --seed 42

# Index
uv run python rag/index.py --db data/wikipedia_pages_hard_10k.sqlite     --index-dir data/index_hard_10k

# RAG eval (generate only)
uv run python eval/run_rag_hard_eval.py --stage generate     --input data/train_hard_subset_10k.jsonl --index-dir data/index_hard_10k     --model gemma-3-4b-it-Q4_K_M.gguf --low-mem

# RAG eval (score only)
uv run python eval/run_rag_hard_eval.py --stage score     --output-dir output --run-name index_hard_10k
```

## Known issues / TODOs

1. FAISS retrieval is in-process, so large dense indexes increase Python RAM usage.
2. PowerShell BOM - `Set-Content -Encoding utf8` can break `json.loads`; write JSONL via Python.
3. `light-clean` index not yet built or evaluated.
4. Full eval not yet completed on the 10k subset.
