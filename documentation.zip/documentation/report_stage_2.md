**authors**: Arseny Pinigin, Tatyana Shmykova

## Project state report — Stage 2

### Planned progress for this stage

According to our original work plan, weeks 4–6 were supposed to be spent on:
- building the structured extractor for sections, infoboxes, and tables;
- designing the API and implementing the mapping from questions to structured fields.

In practice, we completed the trivial question filtering and built a full evaluation pipeline, but most of the time was spent scaling the baseline to the real dataset and solving the infrastructure problems that came with it. The structured extractor has not been started yet.

### Why the plan changed

At the end of Stage 1 the pipeline worked on a test set of 100 Wikipedia pages. We then built a working corpus of 50,000 pages (39,415 pages linked from the training questions plus 10,585 randomly sampled additional pages to make the retrieval task more realistic). This corpus produced approximately 3.9 million chunks after chunking. Indexing completed successfully overnight using embedded Qdrant, but when we tried to run inference on this index, the system ran out of memory. The two main consumers were:

1. **Embedded Qdrant** — the vector index was stored in a local file-based Qdrant instance that loads the full HNSW graph and all vectors into the Python process at query time. With ~3.9M chunks of 1024-dimensional float32 vectors, this consumed a large share of available RAM.
2. **In-memory BM25** — the `rank_bm25` library kept all token statistics and chunk metadata in a Python pickle. For 3.9M chunks the deserialized index was large, and the loading process temporarily required even more memory.

Together with the OS, IDE, and other processes, these exceeded the available RAM. Fixing this turned out to be a larger task than expected and consumed all available time for Stage 2.

## What is done now

### Trivial question filtering

We completed the first item from our Stage 1 "next steps" list: filtering out questions the LLM can answer without any retrieved context. We ran all ~80k questions through Gemma 3 4B without context and checked whether the answer was already correct (EM = 1, or token F1 ≥ 0.8). Questions the model solved on its own were removed, leaving a "hard" subset of **68,019 questions** (`train_hard.jsonl`).

### Replacing BM25 with SQLite FTS5

The old sparse retrieval used the `rank_bm25` Python library. The full BM25 index (token statistics + chunk metadata for all passages) was kept in memory and serialized as a pickle file. This did not scale to millions of chunks.

We replaced it with [SQLite FTS5](https://www.sqlite.org/fts5.html), a full-text search extension built into Python's `sqlite3`. During indexing, each chunk is inserted into a regular table (`passages`) and mirrored into an FTS5 virtual table (`passages_fts`). The inverted index lives on disk inside `passages.sqlite`, so memory usage depends only on the configurable SQLite page cache. FTS5 uses its own BM25-based ranking, so retrieval quality is comparable.

This change also simplified the index structure: instead of two separate files (`qdrant_store/` + `bm25.pkl`), we now have `qdrant_store/` (or Docker) + `passages.sqlite` which stores both texts and the sparse index.

### Qdrant: Docker mode

Embedded Qdrant loads the full HNSW graph into the Python process, which is fast for searching but uses a lot of RAM. We added support for running Qdrant as a Docker container (`docker-compose.qdrant.yml`, image `qdrant/qdrant:v1.13.5`) with a configurable memory limit and a named Docker volume for persistent storage.

In Docker mode, the Python process connects to Qdrant over HTTP/gRPC and only holds the query vector and the response in memory. The embedded mode is still available as an opt-in flag (`--embedded-qdrant`) for cases where the corpus is small enough.

The switching logic is in `rag/qdrant_backend.py`, which provides a single `open_qdrant_client()` function that returns the right client depending on the `ATLAS_QDRANT_EMBEDDED` environment variable.

### Qdrant on-disk storage

By default Qdrant keeps both the vectors and the HNSW graph in RAM. We configured the collection to use on-disk storage for both (`on_disk=True` for vectors and HNSW). In this mode Qdrant uses memory-mapped files, and the operating system caches frequently accessed pages automatically. This reduces the RAM footprint of the vector index to a small fraction of its full size, at the cost of slightly higher search latency. The trade-off is acceptable for our use case since the bottleneck is LLM generation, not retrieval.

### Embedding model on GPU

Jina v3 runs on GPU (CUDA) by default for both indexing and inference. We added a factory module (`rag/embedder_factory.py`) that ensures the model is placed on GPU when CUDA is available, loads with `low_cpu_mem_usage=True` to minimize the temporary CPU RAM spike during initialization, and optionally casts weights to float16 to halve the VRAM footprint. These options are controlled by environment variables and a `--low-mem` flag in the evaluation script.

### Streaming indexing

The old `index.py` loaded all pages into memory before starting to embed them. The new version streams pages from SQLite in configurable batches (`--page-batch`, default 500) and flushes chunks to Qdrant + SQLite every 4096 chunks. After each flush, vectors and temporary objects are explicitly deleted and `gc.collect()` is called to free memory. This way, peak RAM during indexing stays roughly constant regardless of the corpus size.

### Dataset subsetting

Even with all the optimizations above, the full 50k-page corpus (~3.9M chunks) puts significant pressure on system memory. To allow fast iteration on consumer hardware, we built a subsetting script (`eval/build_train_hard_subset.py`) that creates a smaller but self-consistent corpus:

1. collects all Wikipedia page IDs mentioned in `train_hard.jsonl`;
2. checks which of those IDs actually exist in the source database;
3. samples 10,000 pages uniformly at random from that pool (with a fixed seed for reproducibility);
4. keeps only the questions where **every** gold Wikipedia page is present in the sampled set;
5. copies matching pages into a new, smaller SQLite database.

The key constraint in step 4 is that we do not keep a question unless all of its answer sources are available. This guarantees that the corpus always contains the gold passages for every question in the evaluation set. With 10,000 pages this gives **18,328 questions** (out of 68,019) and approximately 1 million chunks.

A limitation of this approach is that the retrieval search space is smaller, so absolute metrics will likely be higher than on the full corpus. However, since we plan to compare the baseline and the structured retrieval pipeline on the same subset, the relative differences remain valid. Questions that reference multiple pages are less likely to survive the filter, which may introduce a slight bias toward simpler, single-source questions.

### Evaluation pipeline

We built a complete evaluation script (`eval/run_rag_hard_eval.py`) that:

- **generates** answers: loads the index, reads the question JSONL, encodes queries in batches of 32 (to reduce embedding overhead), retrieves passages with hybrid search, sends the prompt to llama.cpp, and writes the answers to a JSONL file;
- **scores** answers: loads the answer file, computes EM, token F1, and BERTScore in configurable chunks (default 128), and writes per-question results + an aggregate summary JSON.

The two stages can be run together or separately. When run together, the scoring stage is launched in a fresh subprocess so that the index can be unloaded from memory before the BERTScore model (DeBERTa-xlarge) is loaded.

### Updated pipeline components

| Component | Stage 1 | Stage 2 |
|---|---|---|
| Vector store | Qdrant (embedded, in-RAM) | Qdrant (Docker or embedded, on-disk mmap) |
| Sparse retrieval | BM25 (rank-bm25, in-memory pickle) | SQLite FTS5 (disk-backed) |
| Payload storage | inside Qdrant | separate `passages.sqlite` |
| Embedding model | CPU, float32 | GPU (CUDA), optional float16 |
| Indexing | load all pages → embed → write | streaming batches with explicit `gc.collect()` |
| Evaluation | manual (notebook) | `run_rag_hard_eval.py` with generate/score stages |

## Current status

The pipeline is ready for a full baseline evaluation run. It has been smoke-tested on small subsets (10 pages / 5 questions) and the results look correct. The full run on the 10k-page subset (18,328 questions) has not been executed yet.

No baseline F1 numbers have been measured yet because we have not completed a full evaluation run. This is the immediate next step. 

## Next steps

1. Run the baseline evaluation on the 10k-page subset and get F1 numbers.
2. Start building the structured extractor — the core contribution originally planned for this stage.
3. Compare structured retrieval against the baseline.
4. If time allows, scale evaluation to the full 68k hard-question set using Docker Qdrant.

## Submitted artefacts (new since Stage 1)

- `rag/qdrant_backend.py` — Qdrant client factory (Docker / embedded mode);
- `rag/embedder_factory.py` — embedding model loader with memory-saving options;
- `rag/index.py` — rewritten: streaming indexing, SQLite FTS5, Docker/embedded Qdrant;
- `rag/search.py` — rewritten: FTS5 sparse retrieval, batched passage fetch, Docker Qdrant;
- `rag/migrate_qdrant_to_server.py` — one-time migration from embedded Qdrant to Docker;
- `eval/run_rag_hard_eval.py` — full evaluation pipeline (generate + score);
- `eval/build_train_hard_subset.py` — dataset subsetting tool;
- `docker-compose.qdrant.yml` — Docker Compose for Qdrant server.
