# ATLAS - Project Overview

API for Templated LLM Access to Sources - a hybrid RAG system over Wikipedia, evaluated on hard questions that require external context.

## What this project does

1. Filters training questions to keep only hard ones.
2. Indexes Wikipedia pages: dense vectors (Jina Embeddings v3 -> FAISS) + sparse text search (SQLite FTS5).
3. Retrieves relevant passages using hybrid dense+sparse search with RRF fusion.
4. Generates answers via a local LLM (`llama-server` + Gemma 3 4B GGUF).
5. Scores answers with Exact Match, Token-F1, and BERTScore.

## Setup

Prerequisites: Python >= 3.11, [uv](https://docs.astral.sh/uv/), `llama-server` (via `winget install llama.cpp`).

```powershell
# Install Python deps
uv sync

# Install PyTorch with CUDA
uv pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128

# Download model
mkdir models\gemma3
uvx --from huggingface_hub hf download unsloth/gemma-3-4b-it-GGUF --include "gemma-3-4b-it-Q4_K_M.gguf" --local-dir models\gemma3
```

## Quick start (10k-page subset)

### 1. Build subset (already done, files in `data/`)

```powershell
uv run python eval/build_train_hard_subset.py --num-pages 10000 --seed 42
```

Creates `wikipedia_pages_hard_10k.sqlite` and `train_hard_subset_10k.jsonl`.

### 2. Start LLM server

```powershell
llama-server.exe -m models\gemma3\gemma-3-4b-it-Q4_K_M.gguf -ngl 99 -c 8192 --host 127.0.0.1 --port 8080
```

### 3. Build index

```powershell
uv run python rag/index.py --db data/wikipedia_pages_hard_10k.sqlite --index-dir data/index_hard_10k
```

### 4. Run RAG evaluation

```powershell
# Generate answers
uv run python eval/run_rag_hard_eval.py --stage generate --input data/train_hard_subset_10k.jsonl --index-dir data/index_hard_10k --model gemma-3-4b-it-Q4_K_M.gguf

# Score in a separate process
uv run python eval/run_rag_hard_eval.py --stage score --output-dir output --run-name index_hard_10k
```

Results go to `output/index_hard_10k_answers.jsonl`, `*_results.jsonl`, and `*_summary.json`.

## How the pipeline works

```text
Wikipedia SQLite -> chunk text -> Jina v3 encode -> FAISS (dense)
                 -> chunk text -> SQLite FTS5 (sparse)

Query -> encode -> FAISS top-k --.
      -> FTS5 top-k ---------- +-> RRF merge -> top passages -> LLM prompt -> answer
```

- Dense retrieval: Jina Embeddings v3 (`jinaai/jina-embeddings-v3`), cosine similarity via normalized vectors + inner product.
- Sparse retrieval: SQLite FTS5 with BM25.
- Fusion: Reciprocal Rank Fusion (RRF) with configurable `--sparse-weight` (default 0.3).

## Memory management

| Lever | Flag / env var | Effect |
|-------|----------------|--------|
| FAISS dense index | (default) | Dense vectors are loaded locally for search; simplest setup, higher process RAM |
| GPU embedder | (default when CUDA available) | Jina v3 weights in VRAM, not system RAM |
| Float16 embedder | `--low-mem` or `ATLAS_EMBED_TORCH_DTYPE=float16` | Halves transformer VRAM footprint |
| Smaller batches | `--embed-batch 32`, `--query-embed-batch 8` | Lower peak VRAM per forward pass |

## Project structure

```text
rag/index.py               Build index (chunks -> FAISS + SQLite)
rag/search.py              Hybrid retrieval + RAG answer generation
rag/embedder_factory.py    Jina v3 embedder loader
rag/constants.py           Shared constants

eval/run_rag_hard_eval.py End-to-end evaluation (generate + score)
eval/build_train_hard_subset.py  Create smaller aligned corpus
eval/metrics.py            EM, token-F1, BERTScore
```
