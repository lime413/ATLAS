**authors**: Arseny Pinigin, Tatyana Shmykova

## Project state report — Stage 1

### Planned progress for this stage

For the first 4 weeks we planned to:
- define the benchmark and collect the QA dataset;
- set up Wikipedia data collection and parsing;
- build a baseline RAG pipeline.

## What is done now

Our project's github: https://github.com/lime413/ATLAS

### Dataset

We collected a QA dataset based on Wikipedia from the [KILT benchmark](https://github.com/facebookresearch/KILT/tree/main), using only the Natural Questions section. The Wikipedia corpus was downloaded from the [BLINK project](https://github.com/facebookresearch/BLINK). We implemented XML to HTML conversion for the raw Wikipedia dump and stored all pages in an SQLite database.

Dataset statistics:

| Parameter | Value |
|---|---|
| Questions (train) | ~80,000 |
| Unique Wikipedia pages referenced | ~39,000 |
| Total pages in the corpus | ~5.9M |
| Average page length (after cleanup) | 18–23k characters |

Each question in the dataset has ground-truth answers and links to the source Wikipedia pages (provenance).

### LLM selection

We tested several small language models and chose **Gemma 3 4B** (4-bit GGUF quantization) as the baseline LLM. For inference we use **llama.cpp** with the OpenAI-compatible API, which allows running the model locally on a GPU (we used Vulkan backend). We did a lot here to find an optimal configuration which is feasible for fast experiments with a relatively large dataset on a local PC.

### RAG pipeline

We built a hybrid retrieval-augmented generation pipeline with the following components:

| Component | Tool / Model |
|---|---|
| Dense embeddings | [Jina Embeddings v3](https://huggingface.co/jinaai/jina-embeddings-v3) |
| Vector store | Qdrant (local file storage) |
| Sparse retrieval | BM25 (rank-bm25) |
| Fusion | Reciprocal Rank Fusion |
| LLM inference | Gemma 3 4B via llama.cpp |

The indexing step works as follows:
1. Load Wikipedia pages from SQLite.
2. Clean raw wikitext markup (remove templates, references, HTML tags).
3. Split text into overlapping chunks of 500 characters with 100 character overlap. This gives approximately 1.5M chunks for the full relevant subset.
4. Encode chunks with Jina v3 using the `retrieval.passage` task (correct task assignment improves embeddings quality via internal LoRA adapter).
5. Store vectors in Qdrant and build a BM25 index over the same chunks.

At query time, both dense (Qdrant vector search based on Jina v3 embeddings) and sparse (BM25) retrieval produce candidate chunks. Results are merged using Reciprocal Rank Fusion with a 70/30 weight split in favor of dense retrieval. The top-k passages are then passed as context to the LLM.

### Evaluation

We implemented evaluation metrics for the QA system: Exact Match, token-level F1 and BERTScore. The main metric for comparing baselines is F1.

### Observation: trivial questions

During initial testing we found that the model can answer some questions correctly even without the RAG system (e.g. "what do the 3 dots mean in math"). These questions do not help measure the benefit of retrieval, so they need to be filtered out from the evaluation set.

## Next steps

1. Clean the dataset by removing questions the model answers well without retrieval.
2. Index the full relevant subset of Wikipedia (~39k pages, ~1.5M chunks).
3. Run the RAG pipeline on the filtered dataset and measure F1 against ground-truth answers.
4. Implement page preprocessing using LLM to produce well structured, LLM-friendly content.
5. Run the same RAG evaluation with preprocessed pages and compare F1 to the baseline.

## Submitted artefacts

- `dataset/` — scripts for downloading, parsing and filtering the dataset;
- `eval/metrics.py` — Exact Match, token F1 and BERTScore implementation;
- `rag/index.py` — indexing script (Qdrant + BM25 + Jina v3);
- `rag/search.py` — hybrid retrieval and RAG inference;
- `rag/rag_inference.ipynb` — notebook demonstrating the full pipeline.
